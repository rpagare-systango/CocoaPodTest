//
//  SmilePass.h
//  SmilePass
//
//  Created by stplmacmini14 on 04/12/18.
//  Copyright © 2018 SmilePass. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SmilePass.
FOUNDATION_EXPORT double SmilePassVersionNumber;

//! Project version string for SmilePass.
FOUNDATION_EXPORT const unsigned char SmilePassVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SmilePass/PublicHeader.h>


