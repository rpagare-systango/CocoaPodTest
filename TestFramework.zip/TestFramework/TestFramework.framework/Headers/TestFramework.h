//
//  TestFramework.h
//  TestFramework
//
//  Created by stplmacmini14 on 30/11/18.
//  Copyright © 2018 stplmacmini14. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestFramework.
FOUNDATION_EXPORT double TestFrameworkVersionNumber;

//! Project version string for TestFramework.
FOUNDATION_EXPORT const unsigned char TestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework/PublicHeader.h>


